package com.example.bloodbank.fireStoreDataBase.posts;

import com.google.android.gms.tasks.OnCompleteListener;

import java.util.ArrayList;

public interface PostsCollectionDaoInterface {




}
