package com.example.bloodbank.Utils;

/**
 * Created By Mohamed El Banna On 6/26/2020
 **/
public interface CallbackResult {
    void onResult(Object result);
}
